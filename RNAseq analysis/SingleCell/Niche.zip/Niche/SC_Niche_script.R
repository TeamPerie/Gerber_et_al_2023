
library(Seurat)
library(data.table)

#load the dataset 

#PYMT dataset
Py.data = fread("~/SC_PyMT_Raw_Counts.csv", header = TRUE, data.table = FALSE)
rownames(Py.data) = Py.data$V1
Py.data = Py.data[,-1]

Py.Metadata = fread("~/Medata_SC_PyMT_Raw_Counts.csv",  header = TRUE, data.table = FALSE)
rownames(Py.Metadata) = Py.Metadata$V1
Py.Metadata = Py.Metadata[,-1]

Py = Seurat::CreateSeuratObject(Py.data, project = "PyMT")
Py@meta.data = Py.Metadata

#WT dataset
WT.data = fread("~/SC_WT_Raw_Counts.csv", header = TRUE, data.table = FALSE)
rownames(WT.data) = WT.data$V1
WT.data = WT.data[,-1]

WT.Metadata = fread("~/Medata_SC_WT_Raw_Counts.csv",  header = TRUE, data.table = FALSE)
rownames(WT.Metadata) = WT.Metadata$V1
WT.Metadata = WT.Metadata[,-1]

WT = Seurat::CreateSeuratObject(WT.data, project = "WT")
WT@meta.data = WT.Metadata

#merge the 2 datasets
SC.list = list(WT, Py)
names(SC.list) = c("WT","Py")

###############################################################################
### Normalization and integration
for (i in 1:length(x = SC.list)) {
  SC.list[[i]] <- NormalizeData(object = SC.list[[i]], verbose = FALSE)
  SC.list[[i]] <- FindVariableFeatures(object = SC.list[[i]], 
                                       selection.method = "vst", nfeatures = 2000, verbose = FALSE)
}

SC.anchors <- FindIntegrationAnchors(object.list = SC.list, anchor.features = 2000,
                                     dims = 1:30, k.filter = 100 )

SC.integrated <- IntegrateData(anchorset = SC.anchors, dims = 1:30) 

###############################################################################
### SCALE - PCA -TSNE - UMAP

library(ggplot2)
library(cowplot)

DefaultAssay(object = SC.integrated) <- "integrated"
MaxDim = 30

SC.integrated <- ScaleData(object = SC.integrated, verbose = FALSE)
SC.integrated <- RunPCA(object = SC.integrated, npcs = 100, verbose = FALSE)
SC.integrated <- RunUMAP(object = SC.integrated, reduction = "pca", 
                         dims = 1:MaxDim)
SC.integrated <- RunTSNE(object = SC.integrated, reduction = "pca", 
                         dims = 1:MaxDim)

###############################################################################
###CLUSTERING

SC.integrated <- FindNeighbors(object = SC.integrated, dims = 1:MaxDim)
SC.integrated <- FindClusters(object = SC.integrated, resolution= seq(0, 2, by = 0.1), force.recalc = TRUE)

library(clustree)
clustree(SC.integrated, prefix = "integrated_snn_res.") 

###############################################################################
### Visualization of clusters

library(RColorBrewer)
getPalette = colorRampPalette(brewer.pal(8, "Accent"))
color = getPalette(6)

DimPlot(object = SC.integrated, reduction = "umap", label = TRUE, label.size = 0,
        group.by = "integrated_snn_res.0.1", pt.size = 1.5, cols=color) #+ scale_color_brewer(palette="Dark2")

###############################################################################
### Downsampling PyMT and WT 2000 cells

WT = subset(x = SC.integrated, subset = orig.ident=="WT")
PY = subset(x = SC.integrated, subset = orig.ident=="PyMT")
set.seed(1)

WT <- WT[, sample(colnames(WT), size =2000, replace=F)]
PY <- PY[, sample(colnames(PY), size =2000, replace=F)]

#Density plot
tmp.data<-as.data.frame(Embeddings(object = PY, 
                                   reduction = "umap"))
tmpDensity.ggplot<-ggplot(tmp.data, aes(x = UMAP_1, y = UMAP_2))

tmpDensity.ggplot<-tmpDensity.ggplot + geom_point(colour="#00000000") +
  stat_density_2d(aes(fill = stat(level)), geom = "polygon", bins=25) +
  scale_fill_gradientn(colors = c("#4169E100","royalblue", "darkolivegreen3","goldenrod1","red")) +
  theme_classic() + ggtitle("Density") +
  theme(plot.title = element_text(hjust = 0.5), text = element_text(size = 14))

print(tmpDensity.ggplot + theme(legend.justification='center') + xlim(-15, 15)+ ylim(-15, 15)+ NoLegend())


##########################################################
### Differentially Expressed Genes (Cluster 0: PyMT vs WT)

DefaultAssay(SC.integrated) = "RNA"

#add an annotation table 
SC.integrated$Condition_res0.1 = paste(SC.integrated$orig.ident, SC.integrated$integrated_snn_res.0.1, sep = "_C")
Idents(SC.integrated) = SC.integrated$Condition_res0.1

SC.markers <- FindMarkers(object = SC.integrated, ident.1 = "PyMT_C0", ident.2 = "WT_C0", min.pct = 0.10, only.pos = FALSE, logfc.threshold = 0, 
                          slot="data", test.use = "LR")#, latent.vars = c("orig.ident","Tissue", "Version"))

SC.markers = SC.markers[which(SC.markers$p_val_adj<0.05),]


library(clustree)
clustree(SC.integrated, prefix = "integrated_snn_res.")


Idents(SC.integrated) = SC.integrated$integrated_snn_res.0.1

#save(SC.integrated, file = "~/Documents/StageM2/PyMT_Souris/PAPER/Without_Filters_3000/Selected_Macro_Without_Filters_3000g_StandardWorflux.RData")
#save(SC.markers, file = "~/Documents/StageM2/PyMT_Souris/PAPER/Macro_Mono_DEG_Res0.2_PyMT_1_2_Merged_Without_Gmn.RData")

